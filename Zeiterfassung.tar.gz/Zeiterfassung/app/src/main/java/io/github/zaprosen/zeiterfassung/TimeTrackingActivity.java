package io.github.zaprosen.zeiterfassung;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.interfaces.DSAPrivateKey;
import java.text.DateFormat;
import java.util.Calendar;

public class TimeTrackingActivity extends AppCompatActivity {
    private EditText _startDateTime;
    private EditText _endDateTime;
    private Button _startCommand;
    private Button _endCommand;
    private final DateFormat _dateTimeFormatter =
            DateFormat.getDateTimeInstance(
                    DateFormat.MEDIUM,
                    DateFormat.MEDIUM);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_tracking);
        /*hier fängt es an
        //Gibt Datum und Uhrzeit aus
        EditText startDateTime = findViewById(R.id.StartDateTime);
        startDateTime.setText(Calendar.getInstance().getTime().toString()); */
        _startDateTime = findViewById(R.id.StartDateTime);
        _endDateTime = findViewById(R.id.EndDateTime);
        _startCommand = findViewById(R.id.StartCommand);
        _endCommand = findViewById(R.id.EndCommand);
    }

    @Override
    protected void onResume() {
        super.onResume();
        _startCommand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //log
                // Log.d("TimeTrackingActivity", "onClick für Start-Button aufgerufen");
                //tost
                //Toast.makeText(TimeTrackingActivity.this, "onClick für Start Button aufgerufen", Toast.LENGTH_LONG).show();
                Calendar currentTime = Calendar.getInstance();
               // _startDateTime.setText(currentTime.getTime().toString());
                _startDateTime.setText(
                        _dateTimeFormatter.format(currentTime.getTime()));
            }
        });
        _endCommand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar currentTime =Calendar.getInstance();
            //_endDateTime.setText(currentTime.getTime().toString());
            _endDateTime.setText(
                    _dateTimeFormatter.format(currentTime.getTime()));
            }
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        //Listener deregistrieren
        _startCommand.setOnClickListener(null);
        _endCommand.setOnClickListener(null);
    }

}







